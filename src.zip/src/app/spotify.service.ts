import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class SpotifyService {
  getHeader(query: string) {
 const url = 'https://api.spotify.com/v1/' + query;
 let headers = new HttpHeaders();
 headers = headers.append(
   'Authorization',

   "Bearer BQBw925J-lCUlVyLV8R-nZdCn7J3Mt1T-5SOarTiLy46dp20lmrXy3ehC7CbjpGhoWG0Qjb_UIG1Ww6BCkGDeqC05Dcu9EA4aZ5C_5G0yzU77xo9sf5nNbjp7GIbrKmwdueRK5iUdIg2k8E"
 );
 return this._http.get(url, { headers });
}
//tslint:disable-next-line: variable-name
constructor(private _http: HttpClient) {}

  searchMusic(str: string, type = 'artist') {
    const param = '&offset=0' + '&limit=20' + '&type=' + type + '&market=US';
    const query = 'search?query=' + str + param;
    return this.getHeader(query);
  }
}